"use strict";

// BroadbandCompare App
var app = angular.module('app', ['ionic', 'app.controllers', 'app.routes', 'app.directives', 'app.services']);
// 
var appControllers = angular.module('app.controllers', []);
var appServices = angular.module('app.services', []);
var appDirectives = angular.module('app.directives', []);